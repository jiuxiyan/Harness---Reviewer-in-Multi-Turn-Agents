# Reviewer advice lifetimes: pre-experiment research inputs

This is the curated input package for the public **Harness—Reviewer in Multi-Turn Agents** repository. It contains the research specification, final pre-experiment manuscript and figures, implementation source, tests, and bounded historical evidence needed to integrate a reproducible local project.

**No formal model experiment or efficacy result is included.** The recorded checks used scripted fixtures. This transfer archive is not yet a newly tested standalone release: integration must regenerate public manifests and local fixtures, replace machine-specific historical entrypoint assumptions, and run offline CI. See [integration notes](docs/reproducibility/integration_notes.md).

## Read first

1. [Current protocol and arm definitions](docs/protocol/current_protocol.md)
2. [Final paper](paper/reviewer_advice_lifetimes_preexperiment.docx) and its editable [text source](paper/manuscript.txt)
3. [Historical source map and integration requirements](docs/reproducibility/integration_notes.md)
4. [Recorded offline validation](docs/validation/recorded_offline_checks.json)
5. [License and data boundaries](docs/reproducibility/licenses.md)

## Component map

- `paper/`: exact final DOCX, final PNG/SVG overview, manuscript source, and final document/figure generators. Earlier revision scripts and intermediate renders are excluded.
- `docs/protocol/`: current scientific contract. The final manuscript governs the proposed experiment; the separate offline lifetime overlay extends engineering evidence without supplying model results.
- `docs/research/`: source-cited literature reviews and explicitly historical blueprint/diagram planning. Earlier A/P/R emphasis does not supersede the final primary C/P comparison.
- `docs/history/`: synthesized choice/evidence records for preceding research branches, including negative results and limitations. These are publication-facing summaries.
- `code_inputs/reviewer_pilot/`: pinned official-backend restoration, guarded scripted orchestration, fidelity checks and source hashes.
- `code_inputs/reviewer_interventions/`: immutable proposals, public gate, B/S/A/P wire fixtures, factual receipts and fixture accounting.
- `code_inputs/controller_receipt_adapter/`: observed-output/controller/execution/projection separation, actor-only receipts, persistence and restart tests.
- `code_inputs/advice_lifetime_controls/`: public scope declarations; same-text C, persistent P and one-exposure R projection/state tests.
- `code_inputs/archived/`: deterministic contract-recovery and change-replay sandboxes, and public-data label-audit algorithms. These are historical research branches, not the main experimental runner.
- `tools/fetch_tau2_source.py`: explicit, checksum-verified download of the pinned official allowlist. It never installs or executes fetched code.
- `third_party/`: upstream MIT notice. Official source/data are fetched separately rather than redistributed here.
- `SOURCE_PROVENANCE.json`: original per-file hashes and any public-transfer changes.
- `TRANSFER_MANIFEST.json`: final transfer file sizes/hashes and content scope.

The source snapshot contains the complete current offline implementation and tests. It intentionally contains neither runtime snapshots nor model-generated trajectories. Historic label-audit inputs must be acquired separately after the user reviews their upstream license; they are unnecessary for the current advice-lifetime implementation.
