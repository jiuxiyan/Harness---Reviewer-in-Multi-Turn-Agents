# Pinned official tau2-bench source supplement

This archive contains exactly the 281 official source, test, documentation and public benchmark fixture files selected by SOURCE_MANIFEST.json, at commit 4ce7c0397c1eb65c9bbe59aeacfe1ca44a1cd699. Every upstream file preserves its verified original bytes. It is a selected source closure, not a complete Git repository or installed environment.

The original MIT license is upstream/LICENSE. Keep its copyright and permission notice with any redistribution. Dependency packages are not included and retain their own licenses. Public synthetic benchmark fixture data are official upstream inputs, not private user data or collected model trajectories.

For the research-input package, place the contents of upstream/ at code_inputs/reviewer_pilot/upstream/ (or the equivalent integrated checkout location), then verify all entries against SOURCE_MANIFEST.json. Never treat this archive as a reason to bypass integrity checks or install unverified packages. Source inspection is safe; running source and installing dependencies are separate operator actions.

PROVENANCE.json identifies the exact repository, commit and Git tree. No model experiment, provider request, dependency installation or benchmark execution was performed to prepare this supplement.
